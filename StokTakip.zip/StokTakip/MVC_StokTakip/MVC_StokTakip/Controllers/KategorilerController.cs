﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_StokTakip.Models.Entity;

namespace MVC_StokTakip.Controllers
{
    [Authorize(Roles = "A,U2")]
    public class KategorilerController : Controller
    {
        
        MVC_StokTakipEntities db = new MVC_StokTakipEntities();

        public ActionResult Index(string ara)
        {
            var model = db.Kategorilers.ToList();

            if (!string.IsNullOrEmpty(ara))
            {
                model = model.Where(x => x.Kategori.Contains(ara)).ToList();
            }

            return View(model);
        }

        [HttpGet]
        public ActionResult Ekle()
        {
            return View();
        }

        [HttpPost,ValidateAntiForgeryToken]
        public ActionResult Ekle(Kategoriler p)
        {
            if (!ModelState.IsValid) { return View("Ekle"); }
            db.Kategorilers.Add(p);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        
        public ActionResult GuncelleBilgiGetir(int id)
        {
            var model = db.Kategorilers.Find(id);
            if(model==null) return HttpNotFound();
            return View(model);
        }

        public ActionResult Guncelle(Kategoriler p)
        {
            db.Entry(p).State = System.Data.Entity.EntityState.Modified;
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult SilBilgiGetir(Kategoriler p)
        {
            var model = db.Kategorilers.Find(p.ID);
            if(model==null) return HttpNotFound();
            return View(model);
        }
        public ActionResult Sil(Kategoriler p)
        {
            db.Entry(p).State = System.Data.Entity.EntityState.Deleted;
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}