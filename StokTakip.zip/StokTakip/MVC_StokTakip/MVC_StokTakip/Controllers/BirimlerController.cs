﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_StokTakip.Models.Entity;

namespace MVC_StokTakip.Controllers
{
    [Authorize(Roles = "A,U")]
    public class BirimlerController : Controller
    {
        MVC_StokTakipEntities db = new MVC_StokTakipEntities();

        public ActionResult Index(string ara)
        {
            var model = db.Birimlers.ToList();

            if (!string.IsNullOrEmpty(ara))
            {
                model = model.Where(x => x.Birim.Contains(ara)).ToList();
            }
            return View(model);
        }

        [HttpGet]
        public ActionResult Ekle()
        {
            return View("Kaydet");
        }

        [HttpPost]
        public ActionResult Kaydet(Birimler p)
        {
            if (p.ID==0)
            {
                db.Birimlers.Add(p);
            }
            else
            {
                db.Entry(p).State = System.Data.Entity.EntityState.Modified;
            }
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult GuncelleBilgiGetir(Birimler p)
        {
            var model = db.Birimlers.Find(p.ID);
            if (model == null) return HttpNotFound();
            return View("Kaydet",model);
        }

        public ActionResult SilBilgiGetir(Birimler p)
        {
            var model = db.Birimlers.Find(p.ID);
            if (model == null) return HttpNotFound();
            return View(model);
        }
        public ActionResult Sil(Birimler p)
        {
            db.Entry(p).State = System.Data.Entity.EntityState.Deleted;
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}